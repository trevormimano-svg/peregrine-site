---
name: career-ops-setup
description: >
  One-time intake interview that generates a personalized Career-Ops system: your
  qualification rubric, your honesty-enforced resume engine, your workspace, and your
  two recurring automation prompts. Run this once when you first install the kit.
  Invoke: /career-ops-setup
---

# Career-Ops Setup — Intake Interview & System Generation

You (Claude) are installing the Career-Ops system for THIS user. The kit root is the folder
containing this skill (`career-ops-kit/`). Follow every step in order. Do not skip the
boundary agreement (Step 0) or the smoke test (Step 6).

## Step 0 — The boundary agreement (read aloud to the user, get explicit acknowledgment)

Tell the user, in your own words but keeping every commitment:

> This system runs on a strict human-in-the-loop boundary. It will discover roles, score
> them with a deterministic rubric, and prepare fully tailored application packets and
> outreach drafts — but it will NEVER submit an application, send a message, log into any
> site, or automate any platform (LinkedIn automation violates their terms and risks your
> account). You perform every send and every submit — about 2 minutes each on a prepared
> packet. The resume engine can only use skills and achievements you attest in this
> interview; it is structurally incapable of adding qualifications you don't have. You own
> compliance with your current employer's policies and every platform's terms of use.

Wait for the user to acknowledge before continuing.

## Step 1 — The interview

Ask conversationally (batch related questions; adapt follow-ups). Capture everything:

1. **Current position:** employer, exact title, start date, location. Are you currently
   employed, laid off, or between roles? (This changes urgency + intensity defaults.)
2. **Target roles:** 3–8 exact job titles you want (their words). For each: is it your
   primary lane or a stretch? Then derive: adjacent titles they'd accept.
3. **Geography:** city/region; remote / hybrid / on-site tolerance; relocation yes/no/where.
4. **Compensation:** minimum acceptable base ($k); target base per lane if they know it.
5. **Hard constraints** (become disqualifiers): e.g. no security-clearance-required roles
   (or clearance-required IS their market — ask if they hold one and what "active" means
   for them; NEVER record the clearance level, only "active"/"none"), no travel >X%, visa/
   work-authorization facts, industries they refuse.
6. **The evidence interview (the most important part — take your time):** their 8–15
   highest-value, TRUE achievements. For each: what happened, their specific role, the
   measurable outcome (numbers, scale, dollars, percentages — only real ones), and what
   skills/tools it proves. Push back on vague answers ("led a team" → how many? shipped
   what? measured how?). Also collect: employment history (org/role/dates/2-3 bullets
   each), certifications HELD vs IN PROGRESS (with dates), education, awards.
7. **Truth vocabulary:** from the evidence, derive 10–16 skill clusters (label + the
   variant terms a job description might use). READ THE LIST BACK and ask them to strike
   anything they couldn't defend in an interview tomorrow. This list is the honesty engine —
   nothing outside it can ever appear on a generated resume.
8. **Networks for outreach:** alumni groups, former employers, professional communities,
   veteran networks — ranked by warmth.
9. **Cadence + intensity:** daily scan time; weekly batch day/time; passive (only
   exceptional fits queue) vs active (broader). Laid-off default = active; employed
   default = passive.
10. **Discovery sources:** their job boards; if US-federal-relevant, USAJOBS (free API key —
    point them to `templates/api-access.md`); target-employer watchlist (5–10 names).

## Step 2 — Generate `config/profile.json`

Write the kit's `config/profile.json` with this exact schema (see `sample/profile.sample.json`
for a worked example):
`workspace` (absolute path to their Career-Ops workspace folder — default `<kit-parent>/Career-Ops-Workspace`),
`qualify_threshold` (80 active / 85 passive), `comp_floor_k`,
`title_tiers` (list of `{points: 25|15|10, patterns: [regex...]}` from their primary/adjacent/stretch titles),
`requirement_signals` (list of `{pattern, points}` — e.g. work-auth or clearance phrasing worth 15, "preferred" phrasing worth 10; default entry gives 5),
`comp_lanes` (list of `{min_k, patterns}` per lane + fallback),
`truth_vocabulary` (object: `label -> [variant terms]` — from Step 1.7 ONLY),
`cert_gates` (list of `{name, pattern, status: held|in_progress|not_held}` for certs job ads gate on in their field),
`disqualifiers` (object: `name -> regex` from Step 1.5),
`gap_watchlist` (10–20 tools/terms common in their target JDs that they DON'T have — used for honest gap reporting),
`default_competency_line` (their top 5 truth labels joined with " • ").

## Step 3 — Generate `config/resume_content.json`

Schema (see `sample/resume_content.sample.json`): `name`, `title_line` (market-standard
target title(s) — their documented employer title goes verbatim inside the experience
entry, which is the honest standard practice), `contact_line`, `competency_line`,
`certs_line`, `summary` (3–4 sentences, leads with their biggest business-scale outcome),
`achievements` (5–6, outcome-first, from Step 1.6 only), `expertise` (3 rows of
label: terms — truth vocabulary only), `experience`, `certifications`, `education`,
`awards`, `layout` (`{body_pt: 9.0, margin_in: 0.4}`).

Rules: quantified outcomes lead every bullet; no invented numbers; no filler adjectives
("results-driven", "passionate") — AI screeners and humans both discount them; if they
hold a clearance, write "active security clearance", never the level.

## Step 3.5 — Generate `<workspace>/objectives.md` (the strategy layer)

From the interview, write the user's career-objectives file — the north star every packet
gets aligned against:
- **Target lanes** (primary/secondary) with comp goals per lane and the 12-month objective
  (e.g. "land Senior Platform role at $170k+ remote by <date>", or "internal promotion by
  <review date> with external offers as calibration").
- **Positioning thesis** — 2–3 sentences: what makes them the candidate for their lane
  (from their strongest attested achievements).
- **Development plan (light)** — certs in progress with target dates; the 1–2 skill gaps
  from the gap watchlist worth closing; one external-visibility action per month.
- **LinkedIn surfaces** — generate and store here: headline (<=220 chars, market-standard
  title + top searchable skills), About opening (first 300 chars carry the searchable
  terms), the 15 skills to pin (from truth vocabulary), and a 3-month content calendar
  (one post topic per cadence period, drawn from their expertise, never their employer's
  confidential work). The user pastes these into LinkedIn themselves.
- **Intensity dial** — current setting and the trigger to change it.
The weekly batch checks resume-content drift against these surfaces monthly.

## Step 4 — Create the workspace

Create `<workspace>/` with: `inbox/`, `queue/`, `archive/jd/`, `endpoints.md` (empty
header), `objectives.md` (Step 3.5), `answers-library.md` (standing portal answers built
from the interview: work authorization, availability, relocation/travel, salary phrasing
per lane, the honest "why looking" paragraph, common yes/no traps — the daily scan's
prefill sheets draw from it so every application answers consistently), and `ledger.md`
with the header from `templates/ledger-header.md`. Ledger stage taxonomy (used by the follow-up engine and
analytics): `queued → submitted → screen → interview → offer → closed(won|lost|withdrawn)`.
Tell the user: logging stage changes in the ledger is THE input that drives follow-ups,
interview prep, and the weekly scorecard — 30 seconds per update, high payoff.

## Step 5 — Install the two recurring automations

Fill the `{{PLACEHOLDERS}}` in `templates/task-daily-scan.md` and
`templates/task-weekly-batch.md` with their profile values, then:
- **If this Claude supports scheduled tasks:** create two scheduled tasks (daily scan on
  their weekday time — pick an off-minute like :43; weekly batch on their chosen day).
  Tell them: tasks run while the app is open; missed runs fire at next launch.
- **If not:** save both filled prompts to `<workspace>/prompts/` and tell the user to run
  them as saved prompts each morning / week ("paste or /run the file"). The system works
  identically; only the trigger is manual.

## Step 6 — Smoke test (mandatory — never skip)

0. Confirm the user's working Python command first (`python`, `python3`, or `py` —
   whichever runs Python 3.10+ in THEIR terminal) and use that exact command below.
1. Run the resume builder: `<their-python> engine/build_resume.py <workspace>/queue/_smoketest_resume.docx`
   — confirm it writes and open-check the content with python-docx (name, title line,
   achievement count).
2. Score the sample JD: `<their-python> engine/scout_engine.py --score --jd sample/sample_jd.txt
   --employer SampleCo --title "<their #1 target title>" --url smoke#test --seen-file <workspace>/queue/_smoke_seen.jsonl`
   — confirm a SCORE/VERDICT/BREAKDOWN line prints.
3. Generate the dashboard: `<their-python> engine/dashboard.py --workspace <workspace>` — confirm
   `<workspace>/dashboard.html` exists and open it for the user (their pipeline-at-a-glance
   artifact; every scan and weekly batch regenerates it automatically).
4. Delete the smoke artifacts (keep the dashboard).
5. If python or python-docx is missing, help them install (`pip install python-docx`) and re-run.

## Step 7 — First-run report (end your turn with this)

Give the user: (a) what was generated and where — including their objectives.md and the
LinkedIn surfaces to paste; (b) their cadence and how the trigger works on their setup;
(c) the one manual step list (any API keys from `templates/api-access.md`, saved as
plain-text files the tasks read — values never pasted into chat); (d) the lifecycle map —
what the system now handles agentically (discovery → scoring → full submission packet with
tailored resume + cover letter + prefill + hiring-manager outreach → network outreach →
follow-ups → interview prep & mock drills via /career-ops-interview → negotiation prep →
tracking & analytics) and the one thing it never does (send/submit — that click is theirs);
(e) their first action: drop one real job posting into `inbox/` and run the daily-scan
prompt to watch the pipeline work end to end.
