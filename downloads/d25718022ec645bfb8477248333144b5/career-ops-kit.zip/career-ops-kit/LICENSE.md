# License — Personal Use

Copyright (c) 2026. All rights reserved.

**Grant.** You may use this kit for your own personal job search on your own devices,
and modify your own copy for your own use.

**Not granted.** You may not redistribute, resell, sublicense, or publish this kit or
derivative versions of it, in whole or in part — except that copies received through the
publisher's authorized free-sharing program may be passed on unmodified, in full, under
these same terms. If someone else wants it, point them to
the source you got it from — each person should receive a fresh, unmodified copy (your
`config/` and workspace contain your personal data and must never be shared).

**No automation of third-party platforms.** This kit deliberately automates no job
platform. Modifying it to automate platforms (including LinkedIn) may violate those
platforms' terms of service; you bear all consequences of any modification.

**No warranty.** Provided "as is", without warranty of any kind. See DISCLAIMER.md.

*(Commercial licensing terms, team/outplacement licensing, and support tiers are handled
separately by the publisher — this file governs the personal-use copy only. This license
text has not yet been reviewed by counsel and is subject to replacement.)*
