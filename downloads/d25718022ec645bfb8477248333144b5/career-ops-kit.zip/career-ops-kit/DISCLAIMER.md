# Disclaimer — read this once, it's short

- **This is a productivity tool, not advice.** Nothing in this kit is career counseling,
  legal advice, or a guarantee of interviews or offers.
- **You own every submission.** The system prepares; you review and send. Anything you
  submit is your representation to an employer — review it like it's yours, because it is.
- **Honesty is enforced but attestation is yours.** The engine can only use achievements
  and skills you provided during setup. If you attest something false, the system will
  faithfully repeat your falsehood. Don't.
- **Platform terms are your responsibility.** The kit deliberately automates no platform
  (no LinkedIn automation, no auto-apply, no portal bots). Keep it that way — modifying it
  to automate platforms can get your accounts banned and may violate terms of service.
- **Employer policies are your responsibility.** If you're currently employed, your
  employer may have policies on outside job searching from work devices/networks, on
  disclosing confidential information (never put employer-confidential material into your
  configs), and on side activities. Check them.
- **No warranty.** Provided as-is. Sources get blocked, sites change, models evolve;
  expect to occasionally tune things (GUIDE.md §5).
