# Career-Ops Ledger
<!-- One row per application/outreach. The daily scan and weekly batch maintain this file. -->
<!-- Scan digests and weekly digests are appended as HTML comments above the table. -->
<!-- STAGES: queued -> submitted -> screen -> interview -> offer -> closed(won|lost|withdrawn). -->
<!-- YOUR 30-SECOND JOB: when anything changes (you submitted, they replied, screen booked), update the row's stage+response. Follow-ups, interview prep, and analytics all key off this. -->
| date | type | employer | role | source | score | variant | response | stage |
|---|---|---|---|---|---|---|---|---|
