# Discovery Source Access — key registration guide

Rule for every key/credential: save it as a plain-text file the automation reads
(e.g. `~/.usajobs-secret`) — values never get pasted into a chat conversation.

## USAJOBS (US federal roles) — free, recommended if federal is in your market
1. Go to developer.usajobs.gov → API Request form.
2. Email: your personal email. Company/Agency: "Individual — personal use (job seeker)".
3. Usage description (paste-ready):
   > "Personal, individual job-search use. I will run low-volume, read-only queries against
   > the Search API (a few requests on weekday mornings) filtered to my specialty and
   > locations, to identify announcements I may personally apply to on USAJOBS.gov. No
   > redistribution, no commercial use; I will respect all published rate limits and terms."
4. When the key arrives, save a 2-line file `~/.usajobs-secret`: line 1 = the email you
   registered, line 2 = the key. API calls need three headers: `Host: data.usajobs.gov`,
   `User-Agent: <that email>`, `Authorization-Key: <the key>`.

## Adzuna (broad commercial aggregator) — free, optional
developer.adzuna.com → register an app → app_id + app_key → save both (2 lines) to
`~/.adzuna-secret`. Note: some corporate networks block api.adzuna.com — if your first
call returns a connection failure, record it in endpoints.md and stop retrying.

## No key needed — often the best sources
- **Greenhouse-hosted boards:** `https://boards-api.greenhouse.io/v1/boards/<company>/jobs?content=true`
- **Lever-hosted boards:** `https://api.lever.co/v0/postings/<company>?mode=json`
- **Workday career sites:** find the employer's `<tenant>.myworkdayjobs.com` URL once, then
  use site-scoped web search (`site:<tenant>.myworkdayjobs.com "<keyword>"`). Direct JSON
  endpoints exist but are blocked on some networks — the search fallback always works.

## Email response detection (optional, high-value) — §Email
The weekly batch can auto-detect employer responses instead of you logging them manually.
Setup (~5 minutes, one time):
1. In the Claude app you run this system from: Settings → Connectors/Integrations → connect
   your **personal** Gmail or Outlook account (use a personal machine/account — never mix a
   work mailbox into your job search).
2. In your mailbox, create a label/folder "Job Search" and a filter that applies it to
   mail from senders containing `recruiting`, `talent`, `careers`, `noreply@` + your target
   employers — this keeps the weekly search fast and scoped.
3. That's it — the weekly batch detects the connector automatically and starts matching
   responses to your ledger. It operates READ-ONLY: it never sends, replies, deletes, or
   marks anything, and the kit must never be modified to do so.
Privacy note: this grants your Claude read access to your mailbox — a real tradeoff. The
system works fine without it; you just log responses manually (30 seconds each).

## Explicitly NOT used (and why)
- **LinkedIn automation** — prohibited by LinkedIn's User Agreement; account-ban risk.
  The LinkedIn channel is: their email job alerts → you forward/save them into `inbox/`.
- **Auto-apply services** — bot-detection risk, ToS risk, and recruiters discount them.
  This system's whole design is the opposite: fewer, better, human-submitted applications.
