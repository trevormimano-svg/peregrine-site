#!/usr/bin/env python
"""
dashboard.py — generates a self-contained career-ops dashboard artifact (dashboard.html).

Deterministic, read-only over the workspace: ledger.md (rows + scan/weekly digest comments),
seen.jsonl (scoring history), and queue/ (live packets with expiry countdown). Output is a
single HTML file with inline CSS only — no CDN, no JS dependencies, opens offline anywhere.

Usage: python dashboard.py [--workspace <dir>] [--out <file.html>]
Defaults: workspace = env SCOUT_WORKSPACE, else ../ (the Career-Ops folder this lives in);
          out = <workspace>/dashboard.html
"""
import sys, os, re, io, json, html, pathlib, datetime

def arg(a, flag, default=None):
    return a[a.index(flag) + 1] if flag in a else default

def read(p):
    return io.open(p, encoding="utf-8", errors="ignore").read() if pathlib.Path(p).exists() else ""

def esc(s): return html.escape(str(s))

STAGES = ["queued", "submitted", "screen", "interview", "offer", "closed"]

def main():
    a = sys.argv[1:]
    ws = arg(a, "--workspace") or os.environ.get("SCOUT_WORKSPACE")
    if not ws:
        # kit layout: prefer the workspace declared in config/profile.json over any dir guess
        prof_p = pathlib.Path(__file__).resolve().parent.parent / "config" / "profile.json"
        if prof_p.exists():
            try: ws = json.loads(io.open(prof_p, encoding="utf-8").read()).get("workspace")
            except Exception: ws = None
    ws = pathlib.Path(ws or pathlib.Path(__file__).resolve().parent.parent)
    out = pathlib.Path(arg(a, "--out") or ws / "dashboard.html")
    today = datetime.date.today()

    # ---- parse ledger rows ----
    ledger = read(ws / "ledger.md")
    rows = []
    for line in ledger.splitlines():
        if line.startswith("|") and "---" not in line and "| date |" not in line:
            cells = [c.strip() for c in line.strip("|").split("|")]
            if len(cells) >= 9:
                rows.append(dict(zip(["date","type","employer","role","source","score","variant","response","stage"], cells)))
    # ---- digests (newest last in file) ----
    digests = re.findall(r"<!--\s*(scan|monday|weekly)[^>]*?-->", ledger)
    digest_texts = re.findall(r"<!--\s*((?:scan|monday|weekly)[^>]*?)-->", ledger)
    # ---- seen.jsonl ----
    seen = []
    for line in read(ws / "seen.jsonl").splitlines():
        try: seen.append(json.loads(line))
        except Exception: pass
    verdicts = {}
    for s in seen: verdicts[s.get("verdict","?")] = verdicts.get(s.get("verdict","?"), 0) + 1
    # ---- queue packets + expiry ----
    packets = []
    qdir = ws / "queue"
    if qdir.exists():
        for d in sorted(qdir.iterdir()):
            if d.is_dir():
                m = re.match(r"(\d{8})_", d.name)
                created = datetime.datetime.strptime(m.group(1), "%Y%m%d").date() if m else today
                days_left = 7 - (today - created).days
                packets.append((d.name, created, days_left))
    # ---- pipeline funnel ----
    stage_counts = {s: 0 for s in STAGES}
    for r in rows:
        st = r["stage"].split("(")[0].strip().lower()
        if st in stage_counts: stage_counts[st] += 1
    submitted = sum(stage_counts[s] for s in ["submitted","screen","interview","offer","closed"])
    responses = sum(1 for r in rows if r["response"] not in ("", "—", "-"))
    resp_rate = f"{responses/submitted*100:.0f}%" if submitted else "—"
    interviews = stage_counts["screen"] + stage_counts["interview"] + stage_counts["offer"]

    kpis = [("Roles scored", len(seen)), ("Qualified", verdicts.get("QUALIFY", 0)),
            ("Watching", verdicts.get("WATCH", 0)), ("Live packets", len(packets)),
            ("Submitted", submitted), ("Responses", responses),
            ("Response rate", resp_rate), ("Screens+", interviews)]

    def bar_rows(pairs, color):
        mx = max((v for _, v in pairs), default=0) or 1
        return "".join(
            f"<div class='bl'><span class='blab'>{esc(k)}</span>"
            f"<span class='bwrap'><span class='bar' style='width:{max(3,int(v/mx*100))}%;background:{color}'></span></span>"
            f"<span class='bval'>{v}</span></div>" for k, v in pairs)

    packet_rows = "".join(
        f"<tr class='{ 'warn' if 0 <= dl <= 2 else ('dead' if dl < 0 else '') }'>"
        f"<td>{esc(n)}</td><td>{c}</td><td>{'EXPIRED' if dl < 0 else str(dl)+'d left'}</td></tr>"
        for n, c, dl in packets) or "<tr><td colspan=3>Queue empty — packets appear here after qualifying scans.</td></tr>"

    ledger_rows = "".join(
        f"<tr><td>{esc(r['date'])}</td><td>{esc(r['employer'])}</td><td>{esc(r['role'])[:48]}</td>"
        f"<td>{esc(r['score'])}</td><td>{esc(r['response'])}</td><td><b>{esc(r['stage'])}</b></td></tr>"
        for r in rows[::-1][:25]) or "<tr><td colspan=6>No ledger rows yet.</td></tr>"

    digest_items = "".join(f"<li>{esc(t.strip())}</li>" for t in digest_texts[::-1][:10]) or "<li>No run digests yet.</li>"

    css = """
    body{font-family:Segoe UI,system-ui,sans-serif;margin:0;background:#f4f6f9;color:#1a2333}
    header{background:#101c30;color:#fff;padding:18px 28px}h1{margin:0;font-size:20px;letter-spacing:1px}
    header .sub{color:#9fb3d1;font-size:12px;margin-top:4px}
    main{padding:20px 28px;max-width:1180px;margin:0 auto}
    .cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;margin-bottom:18px}
    .card{background:#fff;border-radius:10px;padding:12px 14px;box-shadow:0 1px 3px rgba(16,28,48,.08)}
    .card .v{font-size:24px;font-weight:700}.card .k{font-size:11px;color:#5a6b85;text-transform:uppercase;letter-spacing:.5px}
    section{background:#fff;border-radius:10px;padding:14px 18px;margin-bottom:16px;box-shadow:0 1px 3px rgba(16,28,48,.08)}
    h2{font-size:13px;text-transform:uppercase;letter-spacing:1px;color:#33415c;border-bottom:1px solid #e3e8f0;padding-bottom:6px;margin:0 0 10px}
    table{width:100%;border-collapse:collapse;font-size:12.5px}td,th{padding:5px 8px;border-bottom:1px solid #eef1f6;text-align:left}
    tr.warn td{background:#fff3e0;font-weight:600}tr.dead td{background:#fde8e8;color:#8a2222}
    .bl{display:flex;align-items:center;margin:4px 0;font-size:12.5px}.blab{width:120px;color:#33415c}
    .bwrap{flex:1;background:#eef1f6;border-radius:4px;height:14px;margin:0 8px}.bar{display:block;height:14px;border-radius:4px}
    .bval{width:30px;text-align:right;font-weight:600}
    ul{margin:0;padding-left:18px;font-size:12px;color:#33415c}li{margin:3px 0;font-family:Consolas,monospace}
    .grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px}@media(max-width:800px){.grid2{grid-template-columns:1fr}}
    footer{color:#5a6b85;font-size:11px;padding:10px 28px 24px;max-width:1180px;margin:0 auto}
    """
    me = pathlib.Path(__file__).resolve().parent.name
    doc = f"""<!doctype html><html><head><meta charset="utf-8"><title>Career-Ops Dashboard</title><style>{css}</style></head>
<body><header><h1>CAREER-OPS DASHBOARD</h1><div class="sub">Generated {datetime.datetime.now():%Y-%m-%d %H:%M} · read-only artifact · regenerate: python {me}/dashboard.py --workspace <your-workspace></div></header><main>
<div class="cards">{''.join(f'<div class="card"><div class="v">{esc(v)}</div><div class="k">{esc(k)}</div></div>' for k, v in kpis)}</div>
<div class="grid2">
<section><h2>Pipeline by stage</h2>{bar_rows([(s.capitalize(), stage_counts[s]) for s in STAGES], '#2f6fb2')}</section>
<section><h2>Scoring verdicts (all-time)</h2>{bar_rows(sorted(verdicts.items(), key=lambda x: -x[1]), '#3f8f5f') if verdicts else '<p style="font-size:12px">No scoring history yet.</p>'}</section>
</div>
<section><h2>Live queue — submit within the window</h2><table><tr><th>Packet</th><th>Created</th><th>Expiry</th></tr>{packet_rows}</table></section>
<section><h2>Applications & outreach (latest 25)</h2><table><tr><th>Date</th><th>Employer</th><th>Role</th><th>Score</th><th>Response</th><th>Stage</th></tr>{ledger_rows}</table></section>
<section><h2>Run digests (latest 10)</h2><ul>{digest_items}</ul></section>
</main><footer>Human-in-the-loop by design: this dashboard reports; you decide and click. Stages: queued → submitted → screen → interview → offer → closed.</footer></body></html>"""
    out.write_text(doc, encoding="utf-8")
    print(f"DASHBOARD {out} ({out.stat().st_size} bytes) | rows={len(rows)} packets={len(packets)} seen={len(seen)} digests={len(digest_texts)}")

if __name__ == "__main__":
    main()
