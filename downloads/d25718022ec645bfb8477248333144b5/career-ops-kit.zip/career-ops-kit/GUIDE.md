# Career-Ops Kit — The Manual

Read README.md first. This is the deep reference: daily operation, tuning, troubleshooting.

## 1. The pipeline (what runs when)

| When | What | Your part |
|---|---|---|
| Weekday morning (your chosen time) | **Daily scan**: WATCH recheck → discovery across your sources → deterministic scoring → tailored packets into `queue/` → digest to `ledger.md` | ~10 min: review new packets, submit the ones you agree with (72-hour freshness is your edge — submit fast) |
| Weekly (your chosen day) | **Weekly batch**: 5 named-person outreach drafts → pipeline scorecard → interview-prep packets for any responses → one staged post | ~20 min: send the 5 messages, publish the post, act on flags |
| Anytime | Drop forwarded job-alert emails or postings into `inbox/` | The next scan ingests them |

Every packet in `queue/` contains: `resume.docx` (tailored), `keyword_report.md` (what was
mirrored, what your gaps are, ATS guidance), `fit_memo.md` (why it qualified + risks),
`cover_letter.md` (full tailored letter), `cover_note.md` (short form), `prefill.md`
(portal answers ready to paste), and `outreach_hm.md` (a hiring-manager message draft).

**How the work is split (so nothing surprises you):** the Python engines produce the
deterministic parts — `resume.docx` and `keyword_report.md` (plus scoring, lint, dedup,
dashboard). Everything judgment-shaped — fit memo, cover letter/note, prefill, outreach —
is written by Claude during the scan run, from your attested content only, and the cover
letter is checked by the deterministic lint before it reaches you. Running the Python tool
by hand gives you the two engine files; the full packet comes from the scan prompt.

## 2. Verdicts and what to do with them

- **QUALIFY** — a packet was built. Review honestly: the fit memo lists the risks the
  scorer found (e.g. a required cert you're still earning). Submit within 72 hours or archive.
- **WATCH** — strong but missing an input (usually listed comp or posting age). The daily
  scan auto-rechecks WATCH items; if the missing datum appears, it re-scores. You can also
  resolve it yourself (one click on the posting) and tell your next scan.
- **REJECT** — didn't clear the bar or hit a hard disqualifier. Counted, not shown.
- **DUPLICATE** — already seen (dedup registry `seen.jsonl`). Silence is correct.

## 3. Tuning your rubric (do this monthly, or when the queue feels wrong)

Your rubric lives in `config/profile.json`. The weekly batch proposes at most one
evidence-based adjustment; you approve by editing the file (or asking Claude to).
Common adjustments:
- **Queue too empty** → lower `qualify_threshold` by 5, or broaden `title_tiers` tier-2 patterns.
- **Queue full of near-misses** → raise threshold, tighten tier-1 title patterns.
- **Wrong geography sneaking in** → add a `disqualifiers` regex.
- **A cert you just earned** → flip its `cert_gates` status to `held` (raises scores where it's required).
- **New skill you can now defend** → add it to `truth_vocabulary` (this is the ONLY way
  anything new can ever appear on a generated resume — by your explicit attestation).

## 4. Resume content changes

`config/resume_content.json` is the single source of truth for every generated resume.
Edit it (or re-run the relevant part of the setup interview) when you have a new
achievement, cert, or role. Rules that keep it working:
- Outcome numbers lead every bullet; only real numbers.
- Your employer's documented title stays verbatim inside the experience entry; the header
  `title_line` is your market-standard target title — both, honestly.
- If you hold a security clearance: "active security clearance", never the level.
- Multi-lane users: keep per-lane summary variants in your notes and pass
  `--summary "..."` to `build_resume.py` for a lane-specific build (phrasing only —
  same attested facts).
- Keep `layout.body_pt` between 8.8 and 9.5 and let content length drive page count; a
  single page should hold ~750-780 words at 9.0pt with 0.4" margins.

## 5. Troubleshooting (the ones that actually happen)

| Symptom | Cause | Fix |
|---|---|---|
| Scan produced nothing, no digest line | The session died mid-run (app closed, network) | Re-run the scan prompt manually; the digest-first rule means completed runs always leave a ledger line |
| A job source always fails with connection errors | Your network (often corporate) blocks it | It's recorded in `endpoints.md` after the first failure; the scan stops retrying. Run scans from a personal network for full coverage |
| Careers page returns an empty shell | JavaScript-rendered page | Expected — the scan uses structured endpoints / site-scoped search instead (see `templates/api-access.md`) |
| `python` startup is slow / times out | Some machines pay a big interpreter startup tax | Re-run with a longer timeout; it's startup cost, not a hang |
| Resume spills to 2 pages | Content grew | Trim the two longest achievements, or drop `layout.body_pt` to 8.8 / `margin_in` to 0.35 |
| Scorer says DUPLICATE for a role you want re-scored | Dedup registry | Re-run with `--url "<url>#rescore1"` |
| `NO PROFILE` / `NO CONTENT` errors | Setup never ran or config moved | Run the setup skill; keep `config/` next to `engine/` |

## 6. Weekly hygiene (5 minutes)

- Log outcomes in `ledger.md` (response? screen? rejection?) — the weekly batch computes
  response rates from it and the interview-prep pipeline triggers off it.
- Archive stale queue items you decided against (the scan auto-archives at 7 days).
- Glance at `endpoints.md` — it's the system's memory of what works on your network.
- Annually (or ~10,000 entries): `python engine/scout_engine.py --compact-seen --keep-days 180`
  trims the dedup registry so lookups stay instant.

## 7. Updating the kit (new versions)

Your personal data lives in exactly two places the kit never ships: `config/` and your
workspace folder. Updating is therefore safe and simple:
1. Check your version: the `VERSION` file (and CHANGELOG.md for what changed).
2. Replace everything EXCEPT `config/` with the new kit's files (or unzip the new kit to a
   fresh folder and copy your old `config/` into it).
3. Run `python verify_install.py` — all checks must pass.
4. If the new version changed the task templates, re-fill the `{{PLACEHOLDERS}}` (ask
   Claude: "re-apply my profile to the updated task templates") and update your recurring
   prompts/tasks.
Your workspace (ledger, queue, seen.jsonl, endpoints, objectives) is untouched by updates.

**Moving machines:** update the `workspace` path in `config/profile.json`, or set the
`SCOUT_WORKSPACE` environment variable (it overrides the profile everywhere) — then run
`python verify_install.py`. Older profiles are auto-migrated: new optional settings get
documented defaults with a one-line advisory.

## 8. Privacy & data

Everything lives in this folder and your workspace folder, on your machine. Nothing is
uploaded anywhere by the kit. Your API keys live in plain-text files in your home
directory that only the automation reads — never paste key values into chat. If you share
this kit onward, share a FRESH copy from the original zip — never your `config/` or
workspace (they contain your personal data).
