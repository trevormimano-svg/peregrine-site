# A note from the person who shared this with you

If you're reading this, someone who cares about your next chapter sent you this kit —
probably because the job market is brutal, layoffs are arbitrary, and doing this alone is
exhausting.

Here's what this is: a system I use myself, every day, to run my own job search like an
operation instead of a doom-scroll. An AI assistant (Claude) does the tedious 95% —
finding roles that actually fit, scoring them against criteria you set, tailoring your
resume to each posting without ever inventing anything, drafting the networking messages
you keep meaning to send — and you do the 5% that should stay human: deciding, and
clicking send.

What it asks of you:
1. **One honest hour up front.** The setup interview asks for your real achievements with
   real numbers. Don't rush it — everything the system produces is built from those answers.
2. **Ten minutes a day.** Review what it queued, submit what you agree with. Speed matters:
   fresh applications get seen.
3. **Twenty minutes a week.** Send the five networking drafts. Real names, real hooks —
   these outperform every job board.

What it will never do: apply on your behalf, message anyone as you, or put a skill on your
resume that you didn't attest. That's not a limitation — it's why your applications will
read like you and not like the bot-spam recruiters are drowning in.

Start with README.md, then tell Claude: *"Read career-ops-kit/skills/career-ops-setup/SKILL.md
and run the setup."*

You've got this. The system just makes sure the effort you're already spending lands where
it counts.
