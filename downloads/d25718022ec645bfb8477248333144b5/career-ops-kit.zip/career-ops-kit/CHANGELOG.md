# Career-Ops Kit — Changelog

## 2.4.0 (adversarial-review hardening)
- Requirement-signals scoring: max-of-all-matching (was order-dependent first-match).
- Profile schema versioning + auto-migration: old profiles get documented defaults with an
  advisory instead of breaking on update; SCOUT_WORKSPACE env var overrides the profile
  workspace everywhere (multi-machine portability).
- Telemetry spine: engines append machine-readable events to workspace/runs.jsonl.
- seen.jsonl compaction: --compact-seen [--keep-days N].
- Capability check added to both task templates: missing web-search degrades VISIBLY.
- Docs: Python-vs-Claude work split explained; full packet contents corrected; --summary
  documented; requirements.txt; smoke-test python-command fix; license free-share carve-out;
  dashboard regeneration hint now layout-aware; honest "Roles scored" KPI.
## 2.3.0
- `verify_install.py` — one-command health check: 9 end-to-end tests against the sample
  persona in a sandbox (never touches your config/workspace). Run after install or update.
- Scorer: automatic compensation extraction from JD text ($150,000–$190,000 / $165k forms)
  when no comp is supplied; title-tier fallback to the JD body at half points (catches
  under-titled postings whose duties match your lanes).
- Friendly config validation: broken/missing profile.json now explains what to fix instead
  of a raw traceback; missing python-docx now says exactly what to install.
- Resume builder: optional `--summary` override for per-lane summary variants.
- Dashboard: workspace resolution now prefers `config/profile.json`'s workspace.
- Versioning (this file + VERSION), LICENSE, and a documented update path (GUIDE §7).

## 2.2.0
- Dashboard artifact: `engine/dashboard.py` → self-contained offline `dashboard.html`
  (KPIs, stage funnel, queue expiry countdown, verdict history, run digests); regenerated
  by every scan and weekly batch; generated at setup smoke-test.

## 2.1.0
- Cover-letter lint (`--lint-letter`): deterministic quality gate (length, banned filler,
  evidence numbers, employer mention) — draft, lint, revise until PASS.
- Standing answers library (workspace `answers-library.md`) feeding every prefill sheet.
- Daily 48-hour packet-expiry flags (was weekly-only).
- Email response detection (connector-conditional, READ-ONLY) in the weekly batch.

## 2.0.0
- Full lifecycle: career-objectives layer + LinkedIn surfaces + content calendar; full
  tailored cover letters; per-role hiring-manager outreach; follow-up engine; ledger stage
  taxonomy; `career-ops-interview` skill (prep briefs, scored mock drills, negotiation prep).

## 1.0.0
- Initial kit: setup interview, deterministic scorer + dedup, honesty-enforced resume
  tailoring, daily scan + weekly batch templates, sample persona.
