# Career-Ops Kit

**A governed, human-in-the-loop career-operations system that runs on your own Claude instance.**

Drop this folder onto your machine, run the setup skill, answer a 15-minute interview, and
you get a personalized system that — every weekday — discovers roles in your target market,
scores them against a rubric built from YOUR criteria (in code, not vibes), and prepares
complete, tailored application packets: a resume mirrored to each job description, a cover
note, and a prefill sheet that makes submitting a 2-minute task. Weekly, it drafts five
personalized networking messages, reviews your pipeline, and preps you for any interviews
that landed.

## What makes this different from "AI job tools"

1. **You click send. Always.** The system never submits an application, never sends a
   message, never logs into anything, and never automates LinkedIn (that violates their
   terms and risks your account). It does ~95% of the work; the last click is yours —
   which is also why your applications read like a person, not a bot.
2. **It cannot lie on your resume.** During setup you attest your real achievements and
   skills; that becomes a "truth vocabulary." The tailoring engine can only mirror job-ad
   phrasing onto skills already in that vocabulary — anything else is reported to you as a
   gap, never added. Structurally enforced, not a promise.
3. **Qualification is deterministic code, not AI mood.** A scored rubric (title fit,
   requirements, compensation band, keyword overlap, freshness, credential gates, hard
   disqualifiers) decides what's worth your time. Tunable, reproducible, auditable.
4. **Fewer, better applications.** Five excellent tailored applications a week beat fifty
   automated ones — 2026 AI screeners *reward* specific, tailored content and *flag*
   generic volume.

## Full lifecycle coverage (what's agentic vs what stays yours)

| Stage | Agentic (automated) | Yours (the click) |
|---|---|---|
| Career objectives & strategy | Objectives file, positioning thesis, development plan, intensity dial | Approve it |
| Discovery | Daily multi-source scan, endpoint learning, dedup | Forward interesting alerts to inbox/ |
| Classification & scoring | Deterministic rubric, disqualifiers, WATCH auto-recheck | Approve rubric tuning proposals |
| Per-role customization | Tailored resume + full cover letter + short note + portal prefill sheet | Review + submit (~2 min) |
| Hiring-manager outreach | Named-person draft per application | Send it the day you submit |
| Network outreach | 5 named-person drafts weekly (alumni, communities, insiders) | Send them |
| LinkedIn & content | Headline/About/skills generation, monthly drift check, post drafts on a calendar | Paste / publish |
| Follow-ups | Auto-drafted at 10 days silent, per-role, rate-limited | Send them |
| Interview prep | Auto prep packet on any response; full prep brief + interactive mock drills + scoring (`/career-ops-interview`) | Rehearse |
| Offer & negotiation | Market-band anchor, value case, negotiation sheet, honest scripts | Negotiate |
| Tracking & analytics | Ledger, stage pipeline, response rates by source, weekly scorecard | Log stage changes (30 sec each) |
| Dashboard | Self-contained `dashboard.html` regenerated after every run — KPIs, stage funnel, live queue with expiry countdown, scoring history, run digests; opens offline in any browser | Glance at it |

The system never sends or submits anything — deliberately. That last click is what keeps
your applications human, your accounts safe, and you in control.

## Install (10 minutes + a 15-minute interview)

1. Requirements: Claude (Claude Code or any Claude with file access + this folder),
   Python 3.10+ with `pip install python-docx` (or `pip install -r requirements.txt`).
   Discovery and outreach need a Claude with WEB SEARCH access — without it, the system
   still scores and tailors, but search-dependent steps are flagged for you to do manually.
2. Put this folder somewhere permanent (e.g. `Desktop/career-ops-kit/`).
3. Tell Claude: **"Read career-ops-kit/skills/career-ops-setup/SKILL.md and run the setup."**
4. Answer the interview honestly — especially the achievements section. The quality of
   everything downstream is set by what you attest there.
4b. Any time you want proof the machinery works: `python verify_install.py` — nine
   end-to-end checks against the bundled sample persona, sandboxed, ~2 minutes.
5. Do the one manual step it gives you (free API key registration where relevant), drop a
   real job posting into your new `inbox/` folder, and run your first scan.

## What's in the box

```
README.md                        this file
GUIDE.md                         the full manual: daily use, troubleshooting, tuning
DISCLAIMER.md                    read it — short and plain
FOR-COLLEAGUES.md                a note from the person who shared this with you
skills/career-ops-setup/         the intake interview that builds YOUR system
skills/career-ops-interview/     on-demand interview prep, mock drills, negotiation prep
engine/scout_engine.py           deterministic scorer + packet builder (reads your profile)
engine/build_resume.py           ATS-safe resume builder (reads your attested content)
engine/dashboard.py              generates dashboard.html — your pipeline at a glance, offline
templates/                       the two recurring automation prompts + API key guide
sample/                          a complete worked example (fictional persona "Jordan Rivera")
config/                          created by setup — YOUR profile + resume content (private)
```

## The honest limits

- Runs while your Claude app is open; missed scheduled runs fire at next launch.
- Some networks (especially corporate) block some job-board APIs — the system detects,
  records, and routes around blocks, but coverage varies by network.
- It prepares; you decide. If you don't review the queue and click submit, nothing happens —
  the 10 minutes a day is real.
- You own compliance with your employer's policies and every platform's terms of use.
