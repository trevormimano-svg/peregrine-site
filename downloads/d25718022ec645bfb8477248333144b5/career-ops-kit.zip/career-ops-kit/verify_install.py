#!/usr/bin/env python
"""
verify_install.py — one-command health check for the Career-Ops kit.

Run this any time something seems off, after installing, or after updating the kit:
    python verify_install.py
It tests the whole engine chain against the bundled SAMPLE persona in a temp directory —
it never touches your config/ or your workspace. Prints a PASS/FAIL table; exit code 0 = healthy.
"""
import sys, os, io, json, shutil, tempfile, subprocess, pathlib

KIT = pathlib.Path(__file__).resolve().parent
PY = sys.executable
results = []

def check(name, fn):
    try:
        detail = fn()
        results.append((name, True, detail or ""))
    except Exception as e:
        results.append((name, False, str(e)[:140]))

def run(args, timeout=180):
    r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    if r.returncode != 0:
        raise RuntimeError((r.stderr or r.stdout)[:140])
    return r.stdout.strip()

def main():
    # Windows consoles often default to cp1252 — force UTF-8 so output never crashes the verifier itself.
    try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception: pass
    check("Python version >= 3.10", lambda: (_ for _ in ()).throw(RuntimeError(sys.version.split()[0]))
          if sys.version_info < (3, 10) else sys.version.split()[0])
    check("python-docx installed", lambda: __import__("docx") and "ok")

    tmp = pathlib.Path(tempfile.mkdtemp(prefix="careerops_verify_"))
    try:
        # stage a sandbox kit-config + workspace from the sample persona (never the user's real config)
        cfg = tmp / "config"; cfg.mkdir()
        prof = json.loads(io.open(KIT / "sample" / "profile.sample.json", encoding="utf-8").read())
        ws = tmp / "workspace"; (ws / "queue").mkdir(parents=True)
        prof["workspace"] = str(ws)
        io.open(cfg / "profile.json", "w", encoding="utf-8").write(json.dumps(prof))
        shutil.copy(KIT / "sample" / "resume_content.sample.json", cfg / "resume_content.json")
        # sandboxed copy of the engine so KIT_ROOT-relative config resolves to the sandbox
        eng = tmp / "engine"; shutil.copytree(KIT / "engine", eng)

        check("Resume builder produces .docx", lambda: run(
            [PY, str(eng / "build_resume.py"), str(tmp / "r.docx")]) and f"{(tmp/'r.docx').stat().st_size} bytes")
        check("Scorer returns SCORE/VERDICT", lambda: (lambda o: o.splitlines()[0] if o.startswith("SCORE") else (_ for _ in ()).throw(RuntimeError(o[:100])))(
            run([PY, str(eng / "scout_engine.py"), "--score", "--jd", str(KIT / "sample" / "sample_jd.txt"),
                 "--employer", "SampleCo", "--title", "Senior Platform Engineer",
                 "--url", "verify#1", "--seen-file", str(tmp / "seen.jsonl")])))
        check("Dedup fires on repeat URL", lambda: "DUPLICATE" in run(
            [PY, str(eng / "scout_engine.py"), "--score", "--jd", str(KIT / "sample" / "sample_jd.txt"),
             "--employer", "SampleCo", "--title", "Senior Platform Engineer",
             "--url", "verify#1", "--seen-file", str(tmp / "seen.jsonl")]) and "ok"
             or (_ for _ in ()).throw(RuntimeError("no DUPLICATE")))
        check("Packet mode builds packet", lambda: run(
            [PY, str(eng / "scout_engine.py"), "--jd", str(KIT / "sample" / "sample_jd.txt"),
             "--employer", "SampleCo", "--title", "Senior Platform Engineer",
             "--ats", "greenhouse", "--out", str(tmp / "packet")]) and
             ("ok" if (tmp / "packet" / "resume.docx").exists() and (tmp / "packet" / "keyword_report.md").exists()
              else (_ for _ in ()).throw(RuntimeError("packet files missing"))))
        bad = tmp / "bad_letter.md"
        bad.write_text("I am a passionate, results-driven team player.", encoding="utf-8")
        check("Letter lint catches junk", lambda: "LINT FAIL" in run(
            [PY, str(eng / "scout_engine.py"), "--lint-letter", str(bad), "--employer", "SampleCo"]) and "ok"
            or (_ for _ in ()).throw(RuntimeError("lint passed junk")))
        (ws / "ledger.md").write_text("| date | type | employer | role | source | score | variant | response | stage |\n|---|---|---|---|---|---|---|---|---|\n", encoding="utf-8")
        check("Dashboard generates", lambda: run(
            [PY, str(eng / "dashboard.py"), "--workspace", str(ws)]) and
            ("ok" if (ws / "dashboard.html").exists() else (_ for _ in ()).throw(RuntimeError("no html"))))
        check("Broken profile gives friendly error", lambda: (lambda o: "ok" if ("PROFILE" in o.stderr or "PROFILE" in o.stdout) else (_ for _ in ()).throw(RuntimeError("raw traceback shown")))(
            subprocess.run([PY, str(eng / "scout_engine.py"), "--score", "--jd", str(KIT / "sample" / "sample_jd.txt"),
                            "--profile", str(tmp / "nonexistent.json")], capture_output=True, text=True, timeout=120)))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    width = max(len(n) for n, _, _ in results)
    fails = 0
    print("\nCAREER-OPS KIT — INSTALL VERIFICATION")
    print("-" * (width + 28))
    for name, ok, detail in results:
        fails += (not ok)
        print(f"{'PASS' if ok else 'FAIL':4}  {name:<{width}}  {detail}")
    print("-" * (width + 28))
    print(("ALL CHECKS PASSED — the kit is healthy." if not fails else
           f"{fails} CHECK(S) FAILED — see GUIDE.md §5 Troubleshooting."))
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
